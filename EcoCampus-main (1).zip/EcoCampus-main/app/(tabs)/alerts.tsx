import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { useApp } from '@/contexts/AppContext';
import AlertCard from '@/components/ui/AlertCard';

type FilterType = 'all' | 'critical' | 'warning' | 'info';

export default function AlertsScreen() {
  const insets = useSafeAreaInsets();
  const { alerts, unreadAlertCount, markAlertRead, markAllAlertsRead } = useApp();
  const [filter, setFilter] = useState<FilterType>('all');

  const filters: { id: FilterType; label: string; icon: string }[] = [
    { id: 'all', label: 'All', icon: 'list' },
    { id: 'critical', label: 'Critical', icon: 'error' },
    { id: 'warning', label: 'Warning', icon: 'warning' },
    { id: 'info', label: 'Info', icon: 'info' },
  ];

  const filteredAlerts =
    filter === 'all' ? alerts : alerts.filter((a) => a.severity === filter);

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 16 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>Alerts</Text>
            <Text style={styles.subtitle}>
              {unreadAlertCount > 0
                ? `${unreadAlertCount} unread alert${unreadAlertCount > 1 ? 's' : ''}`
                : 'All caught up'}
            </Text>
          </View>
          {unreadAlertCount > 0 && (
            <Pressable
              onPress={() => {
                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                markAllAlertsRead();
              }}
              style={({ pressed }) => [styles.markAllBtn, { opacity: pressed ? 0.7 : 1 }]}
            >
              <MaterialIcons name="done-all" size={18} color={theme.primary} />
              <Text style={styles.markAllText}>Mark all read</Text>
            </Pressable>
          )}
        </View>

        {/* Filter Chips */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterRow}
        >
          {filters.map((f) => {
            const count =
              f.id === 'all'
                ? alerts.length
                : alerts.filter((a) => a.severity === f.id).length;
            return (
              <Pressable
                key={f.id}
                onPress={() => {
                  Haptics.selectionAsync();
                  setFilter(f.id);
                }}
                style={[
                  styles.filterChip,
                  filter === f.id && styles.filterChipActive,
                ]}
              >
                <MaterialIcons
                  name={f.icon as any}
                  size={16}
                  color={filter === f.id ? '#FFF' : theme.textSecondary}
                />
                <Text
                  style={[
                    styles.filterChipText,
                    filter === f.id && { color: '#FFF' },
                  ]}
                >
                  {f.label} ({count})
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>

        {/* Unread Summary */}
        {unreadAlertCount > 0 && filter === 'all' && (
          <View style={styles.unreadBanner}>
            <View style={styles.unreadIconCircle}>
              <MaterialIcons name="notifications-active" size={20} color={theme.error} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.unreadTitle}>{unreadAlertCount} New Alert{unreadAlertCount > 1 ? 's' : ''}</Text>
              <Text style={styles.unreadSubtitle}>
                {alerts.filter((a) => !a.read && a.severity === 'critical').length} critical
                {' • '}
                {alerts.filter((a) => !a.read && a.severity === 'warning').length} warning
              </Text>
            </View>
          </View>
        )}

        {/* Alert List */}
        <View style={styles.alertsList}>
          {filteredAlerts.length > 0 ? (
            filteredAlerts.map((alert) => (
              <AlertCard
                key={alert.id}
                alert={alert}
                onPress={() => markAlertRead(alert.id)}
              />
            ))
          ) : (
            <View style={styles.emptyState}>
              <Image
                source={require('@/assets/images/empty-alerts.png')}
                style={styles.emptyImage}
                contentFit="contain"
              />
              <Text style={styles.emptyTitle}>No {filter} alerts</Text>
              <Text style={styles.emptySubtitle}>
                Everything looks good! We'll notify you when something needs attention.
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 4,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  subtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    marginTop: 2,
  },
  markAllBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: `${theme.primary}10`,
    borderRadius: theme.radius.small,
    marginTop: 4,
  },
  markAllText: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.primary,
  },

  // Filters
  filterRow: {
    paddingHorizontal: 16,
    gap: 8,
    paddingTop: 16,
    paddingBottom: 4,
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: theme.surface,
  },
  filterChipActive: {
    backgroundColor: theme.primary,
  },
  filterChipText: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.textSecondary,
  },

  // Unread Banner
  unreadBanner: {
    marginHorizontal: 16,
    marginTop: 14,
    backgroundColor: '#FEF2F2',
    borderRadius: theme.radius.medium,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  unreadIconCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FEE2E2',
    alignItems: 'center',
    justifyContent: 'center',
  },
  unreadTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: theme.error,
  },
  unreadSubtitle: {
    fontSize: 12,
    color: '#991B1B',
    marginTop: 2,
  },

  // Alerts
  alertsList: {
    paddingHorizontal: 16,
    gap: 10,
    marginTop: 14,
  },

  // Empty
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
    gap: 12,
  },
  emptyImage: {
    width: 120,
    height: 120,
    marginBottom: 8,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  emptySubtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    textAlign: 'center',
    paddingHorizontal: 40,
    lineHeight: 20,
  },
});
