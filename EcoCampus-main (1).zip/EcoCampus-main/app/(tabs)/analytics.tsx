import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { useApp } from '@/contexts/AppContext';
import {
  weeklyUsage,
  hourlyUsage,
  predictions,
  monthlyTrend,
  formatNumber,
} from '@/services/mockData';
import BarChart from '@/components/ui/BarChart';

type Period = '24h' | '7d' | '30d';
type MetricType = 'electricity' | 'water';

export default function AnalyticsScreen() {
  const insets = useSafeAreaInsets();
  const { campusTotals } = useApp();
  const [period, setPeriod] = useState<Period>('7d');
  const [metric, setMetric] = useState<MetricType>('electricity');

  const periods: { id: Period; label: string }[] = [
    { id: '24h', label: '24H' },
    { id: '7d', label: '7D' },
    { id: '30d', label: '30D' },
  ];

  const chartData = period === '24h'
    ? hourlyUsage.filter((_, i) => i % 3 === 0).map((h) => ({
        label: `${h.hour}h`,
        value: metric === 'electricity' ? h.electricity : h.water,
      }))
    : period === '7d'
    ? weeklyUsage.map((d) => ({
        label: d.day,
        value: metric === 'electricity' ? d.electricity : d.water,
      }))
    : monthlyTrend.map((m) => ({
        label: m.month,
        value: metric === 'electricity' ? m.electricity : m.water,
      }));

  const barColor = metric === 'electricity' ? theme.accent : theme.secondary;

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 16 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Analytics</Text>
          <Text style={styles.subtitle}>Usage patterns & AI predictions</Text>
        </View>

        {/* Metric Toggle */}
        <View style={styles.metricToggle}>
          <Pressable
            onPress={() => {
              Haptics.selectionAsync();
              setMetric('electricity');
            }}
            style={[
              styles.metricBtn,
              metric === 'electricity' && { backgroundColor: theme.accent },
            ]}
          >
            <MaterialIcons
              name="bolt"
              size={18}
              color={metric === 'electricity' ? '#FFF' : theme.textSecondary}
            />
            <Text
              style={[
                styles.metricBtnText,
                metric === 'electricity' && { color: '#FFF' },
              ]}
            >
              Electricity
            </Text>
          </Pressable>
          <Pressable
            onPress={() => {
              Haptics.selectionAsync();
              setMetric('water');
            }}
            style={[
              styles.metricBtn,
              metric === 'water' && { backgroundColor: theme.secondary },
            ]}
          >
            <MaterialIcons
              name="water-drop"
              size={18}
              color={metric === 'water' ? '#FFF' : theme.textSecondary}
            />
            <Text
              style={[
                styles.metricBtnText,
                metric === 'water' && { color: '#FFF' },
              ]}
            >
              Water
            </Text>
          </Pressable>
        </View>

        {/* Period Selector */}
        <View style={styles.periodRow}>
          {periods.map((p) => (
            <Pressable
              key={p.id}
              onPress={() => {
                Haptics.selectionAsync();
                setPeriod(p.id);
              }}
              style={[
                styles.periodChip,
                period === p.id && styles.periodChipActive,
              ]}
            >
              <Text
                style={[
                  styles.periodChipText,
                  period === p.id && styles.periodChipTextActive,
                ]}
              >
                {p.label}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Chart */}
        <View style={[styles.chartCard, theme.shadows.card]}>
          <Text style={styles.chartTitle}>
            {metric === 'electricity' ? 'Power Consumption' : 'Water Consumption'}
            {' — '}
            {period === '24h' ? 'Today' : period === '7d' ? 'This Week' : '6 Months'}
          </Text>
          <BarChart
            data={chartData}
            height={180}
            barColor={barColor}
            barWidth={period === '30d' ? 36 : period === '24h' ? 28 : 32}
            showValues={period !== '24h'}
          />
        </View>

        {/* AI Prediction Section */}
        <View style={styles.aiSection}>
          <View style={styles.aiHeader}>
            <Image
              source={require('@/assets/images/ai-prediction.png')}
              style={styles.aiIcon}
              contentFit="cover"
            />
            <View>
              <Text style={styles.aiTitle}>AI Predictions</Text>
              <Text style={styles.aiSubtitle}>Machine learning forecast</Text>
            </View>
          </View>
          {predictions.map((pred, index) => (
            <View key={index} style={[styles.predCard, theme.shadows.card]}>
              <View style={styles.predHeader}>
                <Text style={styles.predDate}>{pred.date}</Text>
                <View style={styles.confidenceBadge}>
                  <MaterialIcons name="psychology" size={12} color={theme.primary} />
                  <Text style={styles.confidenceText}>{pred.confidence}% confidence</Text>
                </View>
              </View>
              <View style={styles.predMetrics}>
                <View style={styles.predMetric}>
                  <MaterialIcons name="bolt" size={16} color={theme.accent} />
                  <Text style={styles.predValue}>{formatNumber(pred.predictedElectricity)}</Text>
                  <Text style={styles.predUnit}>kWh</Text>
                </View>
                <View style={styles.predDivider} />
                <View style={styles.predMetric}>
                  <MaterialIcons name="water-drop" size={16} color={theme.secondary} />
                  <Text style={styles.predValue}>{formatNumber(pred.predictedWater)}</Text>
                  <Text style={styles.predUnit}>L</Text>
                </View>
              </View>
            </View>
          ))}
        </View>

        {/* Comparison Stats */}
        <Text style={styles.sectionTitle}>MONTHLY COMPARISON</Text>
        <View style={styles.compRow}>
          {monthlyTrend.slice(-3).map((m, i) => {
            const prev = i > 0 ? monthlyTrend.slice(-3)[i - 1] : null;
            const change = prev
              ? Math.round(((m.electricity - prev.electricity) / prev.electricity) * 100)
              : 0;
            return (
              <View key={m.month} style={[styles.compCard, theme.shadows.card]}>
                <Text style={styles.compMonth}>{m.month}</Text>
                <Text style={styles.compValue}>{formatNumber(m.electricity)}</Text>
                <Text style={styles.compUnit}>kWh</Text>
                {prev && (
                  <View
                    style={[
                      styles.compBadge,
                      { backgroundColor: change >= 0 ? '#FEF2F2' : '#F0FDF4' },
                    ]}
                  >
                    <MaterialIcons
                      name={change >= 0 ? 'trending-up' : 'trending-down'}
                      size={12}
                      color={change >= 0 ? theme.error : theme.success}
                    />
                    <Text
                      style={{
                        fontSize: 11,
                        fontWeight: '600',
                        color: change >= 0 ? theme.error : theme.success,
                      }}
                    >
                      {Math.abs(change)}%
                    </Text>
                  </View>
                )}
              </View>
            );
          })}
        </View>

        {/* Insight Summary */}
        <View style={styles.insightCard}>
          <LinearGradient
            colors={['#064E3B', '#065F46']}
            style={styles.insightGradient}
          >
            <MaterialIcons name="insights" size={28} color="#34D399" />
            <Text style={styles.insightTitle}>Key Insight</Text>
            <Text style={styles.insightText}>
              Peak usage occurs between 8-10 AM and 6-8 PM. Shifting non-critical loads to 
              off-peak hours (2-4 PM) could reduce daily consumption by up to 12%.
            </Text>
          </LinearGradient>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 4,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  subtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    marginTop: 2,
  },

  // Metric toggle
  metricToggle: {
    flexDirection: 'row',
    marginHorizontal: 16,
    marginTop: 16,
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    padding: 4,
    gap: 4,
  },
  metricBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: theme.radius.small,
  },
  metricBtnText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.textSecondary,
  },

  // Period
  periodRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 8,
    marginTop: 14,
  },
  periodChip: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: theme.surface,
  },
  periodChipActive: {
    backgroundColor: theme.primary,
  },
  periodChipText: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.textSecondary,
  },
  periodChipTextActive: {
    color: '#FFF',
  },

  // Chart
  chartCard: {
    marginHorizontal: 16,
    marginTop: 16,
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    padding: 16,
    gap: 12,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.textPrimary,
  },

  // AI
  aiSection: {
    paddingHorizontal: 16,
    marginTop: 24,
    gap: 12,
  },
  aiHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 4,
  },
  aiIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  aiTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  aiSubtitle: {
    fontSize: 12,
    color: theme.textSecondary,
  },
  predCard: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    padding: 14,
    gap: 10,
  },
  predHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  predDate: {
    fontSize: 15,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  confidenceBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: `${theme.primary}10`,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  confidenceText: {
    fontSize: 11,
    fontWeight: '600',
    color: theme.primary,
  },
  predMetrics: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  predMetric: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  predValue: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  predUnit: {
    fontSize: 12,
    color: theme.textSecondary,
  },
  predDivider: {
    width: 1,
    height: 24,
    backgroundColor: theme.border,
    marginHorizontal: 12,
  },

  // Section
  sectionTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: theme.textSecondary,
    letterSpacing: 1,
    paddingHorizontal: 16,
    marginTop: 24,
    marginBottom: 12,
  },

  // Comparison
  compRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 10,
  },
  compCard: {
    flex: 1,
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    padding: 12,
    alignItems: 'center',
    gap: 4,
  },
  compMonth: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.textSecondary,
  },
  compValue: {
    fontSize: 16,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  compUnit: {
    fontSize: 10,
    color: theme.textTertiary,
  },
  compBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    marginTop: 2,
  },

  // Insight
  insightCard: {
    marginHorizontal: 16,
    marginTop: 20,
    borderRadius: theme.radius.large,
    overflow: 'hidden',
  },
  insightGradient: {
    padding: 20,
    gap: 8,
  },
  insightTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFF',
  },
  insightText: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    lineHeight: 20,
  },
});
