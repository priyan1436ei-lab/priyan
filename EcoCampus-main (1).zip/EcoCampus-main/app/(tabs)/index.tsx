import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, RefreshControl } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { useApp } from '@/contexts/AppContext';
import { formatNumber } from '@/services/mockData';
import ProgressRing from '@/components/ui/ProgressRing';
import MetricCard from '@/components/ui/MetricCard';
import ZoneCard from '@/components/ui/ZoneCard';

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { zones, campusTotals, unreadAlertCount, alerts } = useApp();
  const [refreshing, setRefreshing] = useState(false);

  const elecProgress = campusTotals.electricity.today / campusTotals.electricity.limit;
  const waterProgress = campusTotals.water.today / campusTotals.water.limit;

  const criticalAlerts = alerts.filter((a) => !a.read && a.severity === 'critical');

  const onRefresh = () => {
    setRefreshing(true);
    Haptics.selectionAsync();
    setTimeout(() => setRefreshing(false), 800);
  };

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 16 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>EcoCampus</Text>
            <Text style={styles.subtitle}>Live Monitoring Dashboard</Text>
          </View>
          <Pressable
            onPress={() => {
              Haptics.selectionAsync();
              router.push('/(tabs)/alerts');
            }}
            style={({ pressed }) => [styles.bellBtn, { opacity: pressed ? 0.7 : 1 }]}
          >
            <MaterialIcons name="notifications" size={24} color={theme.textPrimary} />
            {unreadAlertCount > 0 && (
              <View style={styles.bellBadge}>
                <Text style={styles.bellBadgeText}>{unreadAlertCount}</Text>
              </View>
            )}
          </Pressable>
        </View>

        {/* Hero Banner */}
        <View style={styles.heroBanner}>
          <Image
            source={require('@/assets/images/hero-banner.png')}
            style={styles.heroBannerImage}
            contentFit="cover"
          />
          <LinearGradient
            colors={['rgba(6,78,59,0.85)', 'rgba(5,150,105,0.75)']}
            style={styles.heroBannerOverlay}
          >
            <View style={styles.ecoScoreRow}>
              <View style={styles.ecoScoreLeft}>
                <Text style={styles.ecoLabel}>CAMPUS ECO SCORE</Text>
                <Text style={styles.ecoScore}>{campusTotals.sustainability.ecoScore}<Text style={styles.ecoScoreUnit}>/100</Text></Text>
              </View>
              <View style={styles.ecoStats}>
                <View style={styles.ecoStat}>
                  <MaterialIcons name="forest" size={16} color="#34D399" />
                  <Text style={styles.ecoStatValue}>{campusTotals.sustainability.treesEquivalent}</Text>
                  <Text style={styles.ecoStatLabel}>trees saved</Text>
                </View>
                <View style={styles.ecoStat}>
                  <MaterialIcons name="cloud" size={16} color="#60A5FA" />
                  <Text style={styles.ecoStatValue}>{campusTotals.sustainability.co2Saved}t</Text>
                  <Text style={styles.ecoStatLabel}>CO₂ reduced</Text>
                </View>
              </View>
            </View>
          </LinearGradient>
        </View>

        {/* Critical Alert Banner */}
        {criticalAlerts.length > 0 && (
          <Pressable
            onPress={() => router.push('/(tabs)/alerts')}
            style={styles.criticalBanner}
          >
            <MaterialIcons name="warning" size={20} color="#FFF" />
            <Text style={styles.criticalText} numberOfLines={1}>
              {criticalAlerts[0].title} — {criticalAlerts[0].zone}
            </Text>
            <MaterialIcons name="chevron-right" size={20} color="#FFF" />
          </Pressable>
        )}

        {/* Live Consumption Rings */}
        <Text style={styles.sectionTitle}>LIVE CONSUMPTION</Text>
        <View style={styles.ringsRow}>
          <View style={styles.ringCard}>
            <ProgressRing
              progress={elecProgress}
              size={130}
              strokeWidth={10}
              color={elecProgress > 0.9 ? theme.error : elecProgress > 0.7 ? theme.warning : theme.accent}
              trackColor="#FEF3C7"
            >
              <MaterialIcons name="bolt" size={22} color={theme.accent} />
              <Text style={styles.ringValue}>{formatNumber(campusTotals.electricity.today)}</Text>
              <Text style={styles.ringUnit}>kWh</Text>
            </ProgressRing>
            <Text style={styles.ringLabel}>Electricity</Text>
            <Text style={styles.ringSubLabel}>of {formatNumber(campusTotals.electricity.limit)} limit</Text>
          </View>
          <View style={styles.ringCard}>
            <ProgressRing
              progress={waterProgress}
              size={130}
              strokeWidth={10}
              color={waterProgress > 0.9 ? theme.error : waterProgress > 0.7 ? theme.warning : theme.secondary}
              trackColor="#DBEAFE"
            >
              <MaterialIcons name="water-drop" size={22} color={theme.secondary} />
              <Text style={styles.ringValue}>{formatNumber(campusTotals.water.today)}</Text>
              <Text style={styles.ringUnit}>Litres</Text>
            </ProgressRing>
            <Text style={styles.ringLabel}>Water</Text>
            <Text style={styles.ringSubLabel}>of {formatNumber(campusTotals.water.limit)} limit</Text>
          </View>
        </View>

        {/* Monthly Savings */}
        <View style={styles.savingsRow}>
          <MetricCard
            icon="bolt"
            label="Saved this month"
            value={`${formatNumber(campusTotals.electricity.savedThisMonth)}`}
            unit="kWh"
            color={theme.accent}
            gradient={theme.gradients.amber}
          />
          <MetricCard
            icon="water-drop"
            label="Saved this month"
            value={`${formatNumber(campusTotals.water.savedThisMonth)}`}
            unit="L"
            color={theme.secondary}
            gradient={theme.gradients.blue}
          />
        </View>

        {/* Cost Snapshot */}
        <Text style={styles.sectionTitle}>MONTHLY COST SNAPSHOT</Text>
        <View style={styles.costRow}>
          <View style={[styles.costCard, theme.shadows.card]}>
            <Text style={styles.costLabel}>EB Bill (Est.)</Text>
            <Text style={styles.costValue}>₹{formatNumber(Math.round(campusTotals.electricity.monthTotal * campusTotals.electricity.costPerUnit))}</Text>
            <View style={styles.costBarBg}>
              <View style={[styles.costBarFill, { width: `${Math.min((campusTotals.electricity.monthTotal / campusTotals.electricity.monthBudget) * 100, 100)}%`, backgroundColor: theme.accent }]} />
            </View>
            <Text style={styles.costBudget}>Budget: ₹{formatNumber(campusTotals.electricity.monthBudget * campusTotals.electricity.costPerUnit)}</Text>
          </View>
          <View style={[styles.costCard, theme.shadows.card]}>
            <Text style={styles.costLabel}>Water Bill (Est.)</Text>
            <Text style={styles.costValue}>₹{formatNumber(Math.round((campusTotals.water.monthTotal / 1000) * campusTotals.water.costPerKL))}</Text>
            <View style={styles.costBarBg}>
              <View style={[styles.costBarFill, { width: `${Math.min((campusTotals.water.monthTotal / campusTotals.water.monthBudget) * 100, 100)}%`, backgroundColor: theme.secondary }]} />
            </View>
            <Text style={styles.costBudget}>Budget: ₹{formatNumber(Math.round((campusTotals.water.monthBudget / 1000) * campusTotals.water.costPerKL))}</Text>
          </View>
        </View>

        {/* Zones */}
        <View style={styles.sectionRow}>
          <Text style={styles.sectionTitle}>ZONE MONITORING</Text>
          <Text style={styles.sectionCount}>{zones.length} zones</Text>
        </View>
        <View style={styles.zonesList}>
          {zones.map((zone) => (
            <ZoneCard
              key={zone.id}
              zone={zone}
              onPress={() => {
                Haptics.selectionAsync();
                router.push(`/zone/${zone.id}`);
              }}
            />
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 12,
  },
  greeting: {
    fontSize: 28,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  subtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    marginTop: 2,
  },
  bellBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: theme.surface,
    alignItems: 'center',
    justifyContent: 'center',
    ...theme.shadows.card,
  },
  bellBadge: {
    position: 'absolute',
    top: 6,
    right: 6,
    backgroundColor: theme.error,
    borderRadius: 8,
    minWidth: 16,
    height: 16,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  bellBadgeText: {
    color: '#FFF',
    fontSize: 9,
    fontWeight: '700',
  },

  // Hero Banner
  heroBanner: {
    marginHorizontal: 16,
    height: 150,
    borderRadius: theme.radius.large,
    overflow: 'hidden',
    marginBottom: 12,
  },
  heroBannerImage: {
    width: '100%',
    height: '100%',
  },
  heroBannerOverlay: {
    ...StyleSheet.absoluteFillObject,
    padding: 16,
    justifyContent: 'center',
  },
  ecoScoreRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  ecoScoreLeft: {
    gap: 4,
  },
  ecoLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.7)',
    letterSpacing: 1,
  },
  ecoScore: {
    fontSize: 48,
    fontWeight: '700',
    color: '#FFF',
  },
  ecoScoreUnit: {
    fontSize: 18,
    fontWeight: '400',
    color: 'rgba(255,255,255,0.6)',
  },
  ecoStats: {
    gap: 10,
  },
  ecoStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  ecoStatValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFF',
  },
  ecoStatLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.7)',
  },

  // Critical Banner
  criticalBanner: {
    marginHorizontal: 16,
    marginBottom: 16,
    backgroundColor: theme.error,
    borderRadius: theme.radius.medium,
    paddingHorizontal: 14,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  criticalText: {
    flex: 1,
    fontSize: 13,
    fontWeight: '600',
    color: '#FFF',
  },

  // Section
  sectionTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: theme.textSecondary,
    letterSpacing: 1,
    paddingHorizontal: 16,
    marginTop: 20,
    marginBottom: 12,
  },
  sectionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingRight: 16,
  },
  sectionCount: {
    fontSize: 12,
    color: theme.textTertiary,
  },

  // Rings
  ringsRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
  },
  ringCard: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    paddingVertical: 20,
    paddingHorizontal: 12,
    ...theme.shadows.card,
  },
  ringValue: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.textPrimary,
    marginTop: 2,
  },
  ringUnit: {
    fontSize: 10,
    fontWeight: '500',
    color: theme.textSecondary,
  },
  ringLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.textPrimary,
    marginTop: 10,
  },
  ringSubLabel: {
    fontSize: 11,
    color: theme.textTertiary,
    marginTop: 2,
  },

  // Savings
  savingsRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
    marginTop: 16,
  },

  // Cost
  costRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
  },
  costCard: {
    flex: 1,
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    padding: 14,
    gap: 6,
  },
  costLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.textSecondary,
  },
  costValue: {
    fontSize: 22,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  costBarBg: {
    height: 4,
    backgroundColor: '#E5E7EB',
    borderRadius: 2,
    overflow: 'hidden',
    marginTop: 4,
  },
  costBarFill: {
    height: 4,
    borderRadius: 2,
  },
  costBudget: {
    fontSize: 11,
    color: theme.textTertiary,
  },

  // Zones
  zonesList: {
    paddingHorizontal: 16,
    gap: 12,
  },
});
