import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { useApp } from '@/contexts/AppContext';
import SuggestionCard from '@/components/ui/SuggestionCard';

type CategoryFilter = 'all' | 'electricity' | 'water' | 'both';

export default function SuggestionsScreen() {
  const insets = useSafeAreaInsets();
  const { suggestions, dismissedSuggestions, dismissSuggestion } = useApp();
  const [catFilter, setCatFilter] = useState<CategoryFilter>('all');

  const activeSuggestions = suggestions.filter(
    (s) => !dismissedSuggestions.includes(s.id)
  );

  const filteredSuggestions =
    catFilter === 'all'
      ? activeSuggestions
      : activeSuggestions.filter((s) => s.category === catFilter);

  const completedCount = dismissedSuggestions.length;
  const totalSavings = suggestions
    .filter((s) => dismissedSuggestions.includes(s.id))
    .map((s) => {
      const match = s.savingsEstimate.match(/[\d,]+/);
      return match ? parseInt(match[0].replace(',', '')) : 0;
    })
    .reduce((a, b) => a + b, 0);

  const categories: { id: CategoryFilter; label: string; icon: string }[] = [
    { id: 'all', label: 'All', icon: 'apps' },
    { id: 'electricity', label: 'Power', icon: 'bolt' },
    { id: 'water', label: 'Water', icon: 'water-drop' },
    { id: 'both', label: 'Combined', icon: 'eco' },
  ];

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 16 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Eco Tips</Text>
          <Text style={styles.subtitle}>AI-powered sustainability suggestions</Text>
        </View>

        {/* Impact Banner */}
        <View style={styles.impactCard}>
          <LinearGradient
            colors={['#064E3B', '#065F46']}
            style={styles.impactGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.impactRow}>
              <View style={styles.impactStat}>
                <Text style={styles.impactValue}>{completedCount}</Text>
                <Text style={styles.impactLabel}>TIPS APPLIED</Text>
              </View>
              <View style={styles.impactDivider} />
              <View style={styles.impactStat}>
                <Text style={styles.impactValue}>{activeSuggestions.length}</Text>
                <Text style={styles.impactLabel}>REMAINING</Text>
              </View>
              <View style={styles.impactDivider} />
              <View style={styles.impactStat}>
                <Text style={styles.impactValue}>
                  {totalSavings > 0 ? `₹${totalSavings.toLocaleString('en-IN')}` : '—'}
                </Text>
                <Text style={styles.impactLabel}>EST. SAVED</Text>
              </View>
            </View>
            <View style={styles.impactBar}>
              <View
                style={[
                  styles.impactBarFill,
                  {
                    width: `${suggestions.length > 0 ? (completedCount / suggestions.length) * 100 : 0}%`,
                  },
                ]}
              />
            </View>
            <Text style={styles.impactBarLabel}>
              {suggestions.length > 0 ? Math.round((completedCount / suggestions.length) * 100) : 0}% sustainability goals achieved
            </Text>
          </LinearGradient>
        </View>

        {/* Priority Legend */}
        <View style={styles.legendRow}>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: theme.error }]} />
            <Text style={styles.legendText}>High Priority</Text>
          </View>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: theme.warning }]} />
            <Text style={styles.legendText}>Medium</Text>
          </View>
          <View style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: theme.info }]} />
            <Text style={styles.legendText}>Low</Text>
          </View>
        </View>

        {/* Category Filters */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.catRow}
        >
          {categories.map((cat) => (
            <Pressable
              key={cat.id}
              onPress={() => {
                Haptics.selectionAsync();
                setCatFilter(cat.id);
              }}
              style={[
                styles.catChip,
                catFilter === cat.id && styles.catChipActive,
              ]}
            >
              <MaterialIcons
                name={cat.icon as any}
                size={16}
                color={catFilter === cat.id ? '#FFF' : theme.textSecondary}
              />
              <Text
                style={[
                  styles.catChipText,
                  catFilter === cat.id && { color: '#FFF' },
                ]}
              >
                {cat.label}
              </Text>
            </Pressable>
          ))}
        </ScrollView>

        {/* Suggestion Cards */}
        <View style={styles.sugList}>
          {filteredSuggestions.length > 0 ? (
            filteredSuggestions.map((sug) => (
              <SuggestionCard
                key={sug.id}
                suggestion={sug}
                onDismiss={() => {
                  Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                  dismissSuggestion(sug.id);
                }}
              />
            ))
          ) : (
            <View style={styles.emptyState}>
              <MaterialIcons name="check-circle" size={64} color={theme.primary} />
              <Text style={styles.emptyTitle}>All tips applied!</Text>
              <Text style={styles.emptySubtitle}>
                {catFilter === 'all'
                  ? 'You\'ve addressed all sustainability suggestions. New tips will appear as AI detects more opportunities.'
                  : `No remaining ${catFilter} suggestions. Try viewing all categories.`}
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 4,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  subtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    marginTop: 2,
  },

  // Impact
  impactCard: {
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: theme.radius.large,
    overflow: 'hidden',
  },
  impactGradient: {
    padding: 20,
    gap: 14,
  },
  impactRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  impactStat: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  impactValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#FFF',
  },
  impactLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.6)',
    letterSpacing: 0.5,
  },
  impactDivider: {
    width: 1,
    height: 32,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  impactBar: {
    height: 6,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  impactBarFill: {
    height: 6,
    backgroundColor: '#34D399',
    borderRadius: 3,
  },
  impactBarLabel: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.7)',
    textAlign: 'center',
  },

  // Legend
  legendRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 20,
    marginTop: 16,
    marginBottom: 4,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  legendText: {
    fontSize: 12,
    color: theme.textSecondary,
  },

  // Categories
  catRow: {
    paddingHorizontal: 16,
    gap: 8,
    paddingTop: 12,
    paddingBottom: 4,
  },
  catChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: theme.surface,
  },
  catChipActive: {
    backgroundColor: theme.primary,
  },
  catChipText: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.textSecondary,
  },

  // List
  sugList: {
    paddingHorizontal: 16,
    gap: 12,
    marginTop: 14,
  },

  // Empty
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
    gap: 12,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  emptySubtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    textAlign: 'center',
    paddingHorizontal: 32,
    lineHeight: 20,
  },
});
