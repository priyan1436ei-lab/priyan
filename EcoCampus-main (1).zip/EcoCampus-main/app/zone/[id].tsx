import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { zones, zoneHourlyData, alerts, getStatusColor, formatNumber } from '@/services/mockData';
import ProgressRing from '@/components/ui/ProgressRing';
import BarChart from '@/components/ui/BarChart';

export default function ZoneDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [activeTab, setActiveTab] = useState<'overview' | 'hourly' | 'alerts'>('overview');

  const zone = zones.find((z) => z.id === id);
  if (!zone) return null;

  const zoneAlerts = alerts.filter((a) => a.zone === zone.name);
  const hourlyData = zoneHourlyData[zone.id] || zoneHourlyData['hostel-a'] || [];
  const statusColor = getStatusColor(zone.status);

  const elecPercent = Math.round((zone.electricity.current / zone.electricity.limit) * 100);
  const waterPercent = Math.round((zone.water.current / zone.water.limit) * 100);

  const tabs: { id: typeof activeTab; label: string; icon: string }[] = [
    { id: 'overview', label: 'Overview', icon: 'dashboard' },
    { id: 'hourly', label: 'Hourly', icon: 'schedule' },
    { id: 'alerts', label: `Alerts (${zoneAlerts.length})`, icon: 'notifications' },
  ];

  return (
    <SafeAreaView edges={['top']} style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable
          onPress={() => {
            Haptics.selectionAsync();
            router.back();
          }}
          style={({ pressed }) => [styles.backBtn, { opacity: pressed ? 0.7 : 1 }]}
        >
          <MaterialIcons name="arrow-back" size={24} color={theme.textPrimary} />
        </Pressable>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>{zone.name}</Text>
          <View style={styles.statusRow}>
            <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
            <Text style={[styles.statusText, { color: statusColor }]}>
              {zone.status.charAt(0).toUpperCase() + zone.status.slice(1)}
            </Text>
            <Text style={styles.updatedText}>• {zone.lastUpdated}</Text>
          </View>
        </View>
        <View style={[styles.zoneIconCircle, { backgroundColor: `${zone.color}15` }]}>
          <MaterialIcons name={zone.icon as any} size={22} color={zone.color} />
        </View>
      </View>

      {/* Tab Bar */}
      <View style={styles.tabBar}>
        {tabs.map((tab) => (
          <Pressable
            key={tab.id}
            onPress={() => {
              Haptics.selectionAsync();
              setActiveTab(tab.id);
            }}
            style={[styles.tab, activeTab === tab.id && styles.tabActive]}
          >
            <MaterialIcons
              name={tab.icon as any}
              size={18}
              color={activeTab === tab.id ? theme.primary : theme.textTertiary}
            />
            <Text
              style={[
                styles.tabText,
                activeTab === tab.id && styles.tabTextActive,
              ]}
            >
              {tab.label}
            </Text>
          </Pressable>
        ))}
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 16 }}
        showsVerticalScrollIndicator={false}
      >
        {activeTab === 'overview' && (
          <>
            {/* Dual Rings */}
            <View style={styles.ringsSection}>
              <View style={styles.ringItem}>
                <ProgressRing
                  progress={zone.electricity.current / zone.electricity.limit}
                  size={140}
                  strokeWidth={12}
                  color={elecPercent > 90 ? theme.error : elecPercent > 70 ? theme.warning : theme.accent}
                  trackColor="#FEF3C7"
                >
                  <MaterialIcons name="bolt" size={20} color={theme.accent} />
                  <Text style={styles.ringVal}>{zone.electricity.current}</Text>
                  <Text style={styles.ringUnitText}>{zone.electricity.unit}</Text>
                </ProgressRing>
                <Text style={styles.ringLbl}>Electricity</Text>
                <Text style={styles.ringPct}>{elecPercent}% of limit</Text>
              </View>
              <View style={styles.ringItem}>
                <ProgressRing
                  progress={zone.water.current / zone.water.limit}
                  size={140}
                  strokeWidth={12}
                  color={waterPercent > 90 ? theme.error : waterPercent > 70 ? theme.warning : theme.secondary}
                  trackColor="#DBEAFE"
                >
                  <MaterialIcons name="water-drop" size={20} color={theme.secondary} />
                  <Text style={styles.ringVal}>{zone.water.current}</Text>
                  <Text style={styles.ringUnitText}>{zone.water.unit}</Text>
                </ProgressRing>
                <Text style={styles.ringLbl}>Water</Text>
                <Text style={styles.ringPct}>{waterPercent}% of limit</Text>
              </View>
            </View>

            {/* Trend Cards */}
            <Text style={styles.sectionTitle}>TREND (VS YESTERDAY)</Text>
            <View style={styles.trendRow}>
              <View style={[styles.trendCard, theme.shadows.card]}>
                <MaterialIcons name="bolt" size={20} color={theme.accent} />
                <Text style={styles.trendLabel}>Power Trend</Text>
                <View style={styles.trendValueRow}>
                  <MaterialIcons
                    name={zone.electricity.trend >= 0 ? 'trending-up' : 'trending-down'}
                    size={20}
                    color={zone.electricity.trend >= 0 ? theme.error : theme.success}
                  />
                  <Text
                    style={[
                      styles.trendValue,
                      { color: zone.electricity.trend >= 0 ? theme.error : theme.success },
                    ]}
                  >
                    {zone.electricity.trend >= 0 ? '+' : ''}{zone.electricity.trend}%
                  </Text>
                </View>
              </View>
              <View style={[styles.trendCard, theme.shadows.card]}>
                <MaterialIcons name="water-drop" size={20} color={theme.secondary} />
                <Text style={styles.trendLabel}>Water Trend</Text>
                <View style={styles.trendValueRow}>
                  <MaterialIcons
                    name={zone.water.trend >= 0 ? 'trending-up' : 'trending-down'}
                    size={20}
                    color={zone.water.trend >= 0 ? theme.error : theme.success}
                  />
                  <Text
                    style={[
                      styles.trendValue,
                      { color: zone.water.trend >= 0 ? theme.error : theme.success },
                    ]}
                  >
                    {zone.water.trend >= 0 ? '+' : ''}{zone.water.trend}%
                  </Text>
                </View>
              </View>
            </View>

            {/* Zone Info */}
            <Text style={styles.sectionTitle}>ZONE DETAILS</Text>
            <View style={[styles.infoCard, theme.shadows.card]}>
              {[
                { icon: 'sensors', label: 'Connected Devices', value: `${zone.devices} sensors` },
                { icon: 'bolt', label: 'Power Limit', value: `${zone.electricity.limit} ${zone.electricity.unit}/day` },
                { icon: 'water-drop', label: 'Water Limit', value: `${zone.water.limit} ${zone.water.unit}/day` },
                { icon: 'update', label: 'Last Updated', value: zone.lastUpdated },
              ].map((item, idx) => (
                <View key={idx} style={[styles.infoRow, idx < 3 && styles.infoRowBorder]}>
                  <MaterialIcons name={item.icon as any} size={20} color={theme.textSecondary} />
                  <Text style={styles.infoLabel}>{item.label}</Text>
                  <Text style={styles.infoValue}>{item.value}</Text>
                </View>
              ))}
            </View>
          </>
        )}

        {activeTab === 'hourly' && (
          <>
            <Text style={styles.sectionTitle}>ELECTRICITY — TODAY (HOURLY)</Text>
            <View style={[styles.chartCard, theme.shadows.card]}>
              <BarChart
                data={hourlyData.filter((_, i) => i % 2 === 0).map((h) => ({
                  label: `${h.hour}h`,
                  value: h.electricity,
                }))}
                height={170}
                barColor={theme.accent}
                barWidth={24}
              />
            </View>

            <Text style={styles.sectionTitle}>WATER — TODAY (HOURLY)</Text>
            <View style={[styles.chartCard, theme.shadows.card]}>
              <BarChart
                data={hourlyData.filter((_, i) => i % 2 === 0).map((h) => ({
                  label: `${h.hour}h`,
                  value: h.water,
                }))}
                height={170}
                barColor={theme.secondary}
                barWidth={24}
              />
            </View>

            {/* Peak Detection */}
            <View style={styles.peakCard}>
              <LinearGradient colors={['#FEF3C7', '#FDE68A']} style={styles.peakGradient}>
                <MaterialIcons name="whatshot" size={24} color={theme.accentDark} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.peakTitle}>Peak Hours Detected</Text>
                  <Text style={styles.peakText}>
                    Highest usage at 7-8 AM and 6-7 PM. Consider staggering equipment operation.
                  </Text>
                </View>
              </LinearGradient>
            </View>
          </>
        )}

        {activeTab === 'alerts' && (
          <View style={styles.alertsList}>
            {zoneAlerts.length > 0 ? (
              zoneAlerts.map((alert) => (
                <View key={alert.id} style={[styles.alertItem, theme.shadows.card]}>
                  <View style={[styles.alertSeverity, { backgroundColor: getSeverityColor(alert.severity) }]} />
                  <View style={styles.alertContent}>
                    <View style={styles.alertHeader}>
                      <MaterialIcons name={alert.icon as any} size={18} color={getSeverityColor(alert.severity)} />
                      <Text style={styles.alertTitle}>{alert.title}</Text>
                    </View>
                    <Text style={styles.alertMessage} numberOfLines={2}>{alert.message}</Text>
                    <Text style={styles.alertTime}>{alert.timestamp}</Text>
                  </View>
                </View>
              ))
            ) : (
              <View style={styles.emptyAlerts}>
                <MaterialIcons name="check-circle" size={48} color={theme.primary} />
                <Text style={styles.emptyTitle}>No alerts for {zone.name}</Text>
                <Text style={styles.emptySubtitle}>All systems operating normally.</Text>
              </View>
            )}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

function getSeverityColor(severity: string): string {
  switch (severity) {
    case 'critical': return '#EF4444';
    case 'warning': return '#F59E0B';
    default: return '#3B82F6';
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: theme.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerCenter: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 2,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '600',
  },
  updatedText: {
    fontSize: 12,
    color: theme.textTertiary,
  },
  zoneIconCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },

  // Tabs
  tabBar: {
    flexDirection: 'row',
    marginHorizontal: 16,
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    padding: 4,
    gap: 4,
    marginBottom: 8,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    paddingVertical: 10,
    borderRadius: theme.radius.small,
  },
  tabActive: {
    backgroundColor: `${theme.primary}15`,
  },
  tabText: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.textTertiary,
  },
  tabTextActive: {
    color: theme.primary,
  },

  // Section
  sectionTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: theme.textSecondary,
    letterSpacing: 1,
    paddingHorizontal: 16,
    marginTop: 20,
    marginBottom: 12,
  },

  // Rings
  ringsSection: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
    marginTop: 8,
  },
  ringItem: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    paddingVertical: 20,
    ...theme.shadows.card,
  },
  ringVal: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.textPrimary,
    marginTop: 2,
  },
  ringUnitText: {
    fontSize: 10,
    color: theme.textSecondary,
  },
  ringLbl: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.textPrimary,
    marginTop: 10,
  },
  ringPct: {
    fontSize: 12,
    color: theme.textTertiary,
    marginTop: 2,
  },

  // Trend
  trendRow: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
  },
  trendCard: {
    flex: 1,
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    padding: 14,
    gap: 8,
  },
  trendLabel: {
    fontSize: 13,
    fontWeight: '500',
    color: theme.textSecondary,
  },
  trendValueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  trendValue: {
    fontSize: 22,
    fontWeight: '700',
  },

  // Info
  infoCard: {
    marginHorizontal: 16,
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    overflow: 'hidden',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    gap: 12,
  },
  infoRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: theme.borderLight,
  },
  infoLabel: {
    flex: 1,
    fontSize: 14,
    color: theme.textSecondary,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.textPrimary,
  },

  // Chart
  chartCard: {
    marginHorizontal: 16,
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    padding: 16,
  },

  // Peak
  peakCard: {
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: theme.radius.medium,
    overflow: 'hidden',
  },
  peakGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 12,
  },
  peakTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.accentDark,
  },
  peakText: {
    fontSize: 13,
    color: '#92400E',
    marginTop: 2,
    lineHeight: 18,
  },

  // Alerts
  alertsList: {
    paddingHorizontal: 16,
    gap: 10,
    marginTop: 8,
  },
  alertItem: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    flexDirection: 'row',
    overflow: 'hidden',
  },
  alertSeverity: {
    width: 4,
  },
  alertContent: {
    flex: 1,
    padding: 14,
    gap: 6,
  },
  alertHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  alertTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  alertMessage: {
    fontSize: 13,
    color: theme.textSecondary,
    lineHeight: 18,
  },
  alertTime: {
    fontSize: 11,
    color: theme.textTertiary,
  },

  // Empty
  emptyAlerts: {
    alignItems: 'center',
    paddingVertical: 40,
    gap: 10,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  emptySubtitle: {
    fontSize: 14,
    color: theme.textSecondary,
  },
});
