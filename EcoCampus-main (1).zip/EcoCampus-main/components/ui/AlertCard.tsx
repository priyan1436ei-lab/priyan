import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { Alert as AlertType, getSeverityColor } from '@/services/mockData';

interface Props {
  alert: AlertType;
  onPress: () => void;
}

export default function AlertCard({ alert, onPress }: Props) {
  const severityColor = getSeverityColor(alert.severity);

  const handlePress = () => {
    if (alert.severity === 'critical') {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    } else {
      Haptics.selectionAsync();
    }
    onPress();
  };

  return (
    <Pressable
      onPress={handlePress}
      style={({ pressed }) => [
        styles.card,
        theme.shadows.card,
        !alert.read && styles.unread,
        { opacity: pressed ? 0.9 : 1 },
      ]}
    >
      <View style={[styles.severityStripe, { backgroundColor: severityColor }]} />
      <View style={styles.content}>
        <View style={styles.header}>
          <View style={[styles.iconCircle, { backgroundColor: `${severityColor}15` }]}>
            <MaterialIcons name={alert.icon as any} size={20} color={severityColor} />
          </View>
          <View style={styles.headerText}>
            <Text style={styles.title} numberOfLines={1}>{alert.title}</Text>
            <View style={styles.metaRow}>
              <Text style={styles.zone}>{alert.zone}</Text>
              <Text style={styles.dot}>•</Text>
              <Text style={styles.time}>{alert.timestamp}</Text>
            </View>
          </View>
          {!alert.read && <View style={styles.unreadDot} />}
        </View>
        <Text style={styles.message} numberOfLines={2}>{alert.message}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.medium,
    flexDirection: 'row',
    overflow: 'hidden',
  },
  unread: {
    backgroundColor: '#F0FDF4',
  },
  severityStripe: {
    width: 4,
  },
  content: {
    flex: 1,
    padding: 14,
    gap: 8,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  iconCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    flex: 1,
  },
  title: {
    fontSize: 15,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  },
  zone: {
    fontSize: 12,
    fontWeight: '500',
    color: theme.textSecondary,
  },
  dot: {
    fontSize: 12,
    color: theme.textTertiary,
  },
  time: {
    fontSize: 12,
    color: theme.textTertiary,
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: theme.primary,
  },
  message: {
    fontSize: 13,
    color: theme.textSecondary,
    lineHeight: 18,
    marginLeft: 46,
  },
});
