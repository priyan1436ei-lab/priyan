import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { theme } from '@/constants/theme';

interface BarData {
  label: string;
  value: number;
  maxValue?: number;
}

interface Props {
  data: BarData[];
  height?: number;
  barColor?: string;
  barWidth?: number;
  showValues?: boolean;
}

export default function BarChart({
  data,
  height = 160,
  barColor = theme.primary,
  barWidth = 32,
  showValues = false,
}: Props) {
  const maxVal = Math.max(...data.map((d) => d.value), 1);

  return (
    <View style={[styles.container, { height: height + 30 }]}>
      <View style={[styles.chartArea, { height }]}>
        {data.map((item, index) => {
          const barHeight = (item.value / maxVal) * (height - 20);
          return (
            <View key={index} style={styles.barGroup}>
              {showValues && (
                <Text style={styles.valueText}>{item.value}</Text>
              )}
              <View style={[styles.barBg, { height: height - 20 }]}>
                <View
                  style={[
                    styles.bar,
                    {
                      height: barHeight,
                      width: barWidth,
                      backgroundColor: barColor,
                    },
                  ]}
                />
              </View>
              <Text style={styles.label}>{item.label}</Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
  },
  chartArea: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingHorizontal: 4,
  },
  barGroup: {
    alignItems: 'center',
    flex: 1,
    gap: 4,
  },
  barBg: {
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  bar: {
    borderRadius: 4,
    minHeight: 4,
  },
  label: {
    fontSize: 11,
    fontWeight: '500',
    color: theme.textTertiary,
  },
  valueText: {
    fontSize: 10,
    fontWeight: '600',
    color: theme.textSecondary,
  },
});
