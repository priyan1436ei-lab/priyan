import React from 'react';
import { View, Text, StyleSheet, Pressable, Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { theme } from '@/constants/theme';

interface Props {
  icon: string;
  label: string;
  value: string;
  unit?: string;
  trend?: number;
  color?: string;
  gradient?: readonly [string, string, ...string[]];
  onPress?: () => void;
}

export default function MetricCard({
  icon,
  label,
  value,
  unit,
  trend,
  color = theme.primary,
  gradient,
  onPress,
}: Props) {
  const content = (
    <>
      <View style={styles.topRow}>
        <View style={[styles.iconCircle, { backgroundColor: gradient ? 'rgba(255,255,255,0.2)' : `${color}15` }]}>
          <MaterialIcons name={icon as any} size={20} color={gradient ? '#FFF' : color} />
        </View>
        {trend !== undefined && (
          <View style={[styles.trendBadge, { backgroundColor: trend >= 0 ? '#FEF2F2' : '#F0FDF4' }]}>
            <MaterialIcons
              name={trend >= 0 ? 'trending-up' : 'trending-down'}
              size={14}
              color={trend >= 0 ? theme.error : theme.success}
            />
            <Text style={[styles.trendText, { color: trend >= 0 ? theme.error : theme.success }]}>
              {Math.abs(trend)}%
            </Text>
          </View>
        )}
      </View>
      <Text style={[styles.value, gradient && { color: '#FFF' }]}>{value}</Text>
      <Text style={[styles.label, gradient && { color: 'rgba(255,255,255,0.7)' }]}>
        {unit ? `${unit} • ` : ''}{label}
      </Text>
    </>
  );

  if (gradient) {
    return (
      <Pressable onPress={onPress} style={({ pressed }) => [{ flex: 1, opacity: pressed ? 0.9 : 1 }]}>
        <LinearGradient colors={gradient} style={styles.card} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
          {content}
        </LinearGradient>
      </Pressable>
    );
  }

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        styles.cardWhite,
        { opacity: pressed ? 0.9 : 1 },
        theme.shadows.card,
      ]}
    >
      {content}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    padding: 16,
    borderRadius: theme.radius.large,
    gap: 8,
  },
  cardWhite: {
    backgroundColor: theme.surface,
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  iconCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  trendBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
  },
  trendText: {
    fontSize: 11,
    fontWeight: '600',
  },
  value: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  label: {
    fontSize: 12,
    fontWeight: '500',
    color: theme.textSecondary,
  },
});
