import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { theme } from '@/constants/theme';
import { Suggestion } from '@/services/mockData';

interface Props {
  suggestion: Suggestion;
  onDismiss: () => void;
}

export default function SuggestionCard({ suggestion, onDismiss }: Props) {
  const priorityColor =
    suggestion.priority === 'high' ? theme.error :
    suggestion.priority === 'medium' ? theme.warning :
    theme.info;

  const categoryColor = suggestion.category === 'electricity' ? theme.accent :
    suggestion.category === 'water' ? theme.secondary : theme.primary;

  return (
    <View style={[styles.card, theme.shadows.card]}>
      <View style={styles.header}>
        <View style={[styles.iconCircle, { backgroundColor: `${categoryColor}15` }]}>
          <MaterialIcons name={suggestion.icon as any} size={22} color={categoryColor} />
        </View>
        <View style={styles.headerText}>
          <Text style={styles.title}>{suggestion.title}</Text>
          <View style={styles.badges}>
            <View style={[styles.priorityBadge, { backgroundColor: `${priorityColor}15` }]}>
              <Text style={[styles.priorityText, { color: priorityColor }]}>
                {suggestion.priority.toUpperCase()}
              </Text>
            </View>
            <View style={[styles.categoryBadge, { backgroundColor: `${categoryColor}15` }]}>
              <Text style={[styles.categoryText, { color: categoryColor }]}>
                {suggestion.category === 'both' ? '⚡💧' : suggestion.category === 'electricity' ? '⚡' : '💧'}
              </Text>
            </View>
          </View>
        </View>
      </View>
      <Text style={styles.description}>{suggestion.description}</Text>
      <View style={styles.footer}>
        <View style={styles.savingsRow}>
          <MaterialIcons name="savings" size={16} color={theme.success} />
          <Text style={styles.savingsText}>Estimated: {suggestion.savingsEstimate}</Text>
        </View>
        <Pressable
          onPress={() => {
            Haptics.selectionAsync();
            onDismiss();
          }}
          style={({ pressed }) => [styles.dismissBtn, { opacity: pressed ? 0.7 : 1 }]}
        >
          <Text style={styles.dismissText}>Done</Text>
          <MaterialIcons name="check" size={16} color={theme.primary} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    padding: 16,
    gap: 12,
  },
  header: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
  },
  iconCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    flex: 1,
    gap: 6,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  badges: {
    flexDirection: 'row',
    gap: 6,
  },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
  },
  priorityText: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  categoryBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
  },
  categoryText: {
    fontSize: 10,
    fontWeight: '700',
  },
  description: {
    fontSize: 14,
    color: theme.textSecondary,
    lineHeight: 20,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 4,
    borderTopWidth: 1,
    borderTopColor: theme.borderLight,
  },
  savingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  savingsText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.success,
  },
  dismissBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: `${theme.primary}10`,
    borderRadius: theme.radius.small,
  },
  dismissText: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.primary,
  },
});
