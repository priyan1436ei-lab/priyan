import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { theme } from '@/constants/theme';
import { Zone, getStatusColor } from '@/services/mockData';

interface Props {
  zone: Zone;
  onPress: () => void;
}

export default function ZoneCard({ zone, onPress }: Props) {
  const elecPercent = Math.round((zone.electricity.current / zone.electricity.limit) * 100);
  const waterPercent = Math.round((zone.water.current / zone.water.limit) * 100);
  const statusColor = getStatusColor(zone.status);

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.card, theme.shadows.card, { opacity: pressed ? 0.9 : 1 }]}
    >
      <View style={styles.header}>
        <View style={[styles.iconCircle, { backgroundColor: `${zone.color}15` }]}>
          <MaterialIcons name={zone.icon as any} size={22} color={zone.color} />
        </View>
        <View style={styles.headerText}>
          <Text style={styles.zoneName}>{zone.name}</Text>
          <Text style={styles.lastUpdated}>{zone.lastUpdated}</Text>
        </View>
        <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
      </View>

      <View style={styles.metricsRow}>
        <View style={styles.metric}>
          <View style={styles.metricHeader}>
            <MaterialIcons name="bolt" size={14} color={theme.accent} />
            <Text style={styles.metricLabel}>Power</Text>
          </View>
          <Text style={styles.metricValue}>{zone.electricity.current} <Text style={styles.metricUnit}>{zone.electricity.unit}</Text></Text>
          <View style={styles.barBg}>
            <View
              style={[
                styles.barFill,
                {
                  width: `${Math.min(elecPercent, 100)}%`,
                  backgroundColor: elecPercent > 90 ? theme.error : elecPercent > 70 ? theme.warning : theme.success,
                },
              ]}
            />
          </View>
        </View>
        <View style={styles.divider} />
        <View style={styles.metric}>
          <View style={styles.metricHeader}>
            <MaterialIcons name="water-drop" size={14} color={theme.secondary} />
            <Text style={styles.metricLabel}>Water</Text>
          </View>
          <Text style={styles.metricValue}>{zone.water.current} <Text style={styles.metricUnit}>{zone.water.unit}</Text></Text>
          <View style={styles.barBg}>
            <View
              style={[
                styles.barFill,
                {
                  width: `${Math.min(waterPercent, 100)}%`,
                  backgroundColor: waterPercent > 90 ? theme.error : waterPercent > 70 ? theme.warning : theme.success,
                },
              ]}
            />
          </View>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.surface,
    borderRadius: theme.radius.large,
    padding: 16,
    gap: 14,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  iconCircle: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerText: {
    flex: 1,
  },
  zoneName: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.textPrimary,
  },
  lastUpdated: {
    fontSize: 12,
    color: theme.textTertiary,
    marginTop: 1,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  metricsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  divider: {
    width: 1,
    backgroundColor: theme.border,
  },
  metric: {
    flex: 1,
    gap: 4,
  },
  metricHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metricLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: theme.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  metricValue: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.textPrimary,
  },
  metricUnit: {
    fontSize: 12,
    fontWeight: '400',
    color: theme.textSecondary,
  },
  barBg: {
    height: 4,
    backgroundColor: '#E5E7EB',
    borderRadius: 2,
    overflow: 'hidden',
    marginTop: 2,
  },
  barFill: {
    height: 4,
    borderRadius: 2,
  },
});
