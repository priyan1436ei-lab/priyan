export const config = {
  appName: 'EcoCampus',
  version: '1.0.0',
  description: 'Smart Energy & Water Monitoring Dashboard',

  // Zones
  zones: ['Hostel A', 'Hostel B', 'Lab Block', 'Canteen', 'Library', 'Admin Block'],

  // Units
  units: {
    electricity: 'kWh',
    water: 'L',
    cost: '₹',
  },

  // Thresholds
  thresholds: {
    electricity: {
      normal: 500,
      warning: 750,
      critical: 1000,
    },
    water: {
      normal: 2000,
      warning: 3000,
      critical: 4000,
    },
  },

  // Alert types
  alertTypes: {
    HIGH_POWER: 'high_power',
    WATER_LEAK: 'water_leak',
    ABNORMAL_SPIKE: 'abnormal_spike',
    PREDICTION_WARNING: 'prediction_warning',
    SAVING_TIP: 'saving_tip',
  },

  // Refresh intervals (in ms) - simulated
  refreshInterval: 30000,
};
