import { Platform } from 'react-native';

export const theme = {
  // Primary - Sustainability Green
  primary: '#10B981',
  primaryLight: '#34D399',
  primaryDark: '#059669',

  // Secondary - Water Blue
  secondary: '#3B82F6',
  secondaryLight: '#60A5FA',
  secondaryDark: '#1D4ED8',

  // Accent - Energy Amber
  accent: '#F59E0B',
  accentLight: '#FCD34D',
  accentDark: '#D97706',

  // Semantic
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  info: '#3B82F6',

  // Backgrounds
  background: '#F0FDF4',
  backgroundSecondary: '#FFFFFF',
  surface: '#FFFFFF',
  surfaceElevated: '#FFFFFF',

  // Text
  textPrimary: '#111827',
  textSecondary: '#6B7280',
  textTertiary: '#9CA3AF',

  // Borders
  border: '#E5E7EB',
  borderLight: '#F3F4F6',

  // Dark surfaces (for contrast cards)
  darkSurface: '#064E3B',
  darkSurfaceLight: '#065F46',

  // Gradients
  gradients: {
    green: ['#10B981', '#059669'] as const,
    blue: ['#3B82F6', '#1D4ED8'] as const,
    amber: ['#F59E0B', '#D97706'] as const,
    dark: ['#064E3B', '#065F46'] as const,
    eco: ['#10B981', '#3B82F6'] as const,
  },

  // Shadows
  shadows: {
    card: Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4 },
      android: { elevation: 2 },
      default: {},
    }),
    cardElevated: Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8 },
      android: { elevation: 4 },
      default: {},
    }),
    modal: Platform.select({
      ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.16, shadowRadius: 12 },
      android: { elevation: 8 },
      default: {},
    }),
  },

  // Border Radius
  radius: {
    small: 8,
    medium: 12,
    large: 16,
    xl: 20,
    full: 9999,
  },

  // Spacing
  spacing: {
    xs: 4,
    sm: 8,
    md: 12,
    lg: 16,
    xl: 20,
    xxl: 24,
  },

  // Typography (Dashboard Archetype A)
  typography: {
    heroData: { fontSize: 48, fontWeight: '700' as const },
    heroLabel: { fontSize: 11, fontWeight: '600' as const, textTransform: 'uppercase' as const, letterSpacing: 1 },
    cardTitle: { fontSize: 16, fontWeight: '600' as const },
    cardValue: { fontSize: 24, fontWeight: '700' as const },
    body: { fontSize: 15, fontWeight: '400' as const },
    caption: { fontSize: 13, fontWeight: '400' as const },
    sectionHeader: { fontSize: 14, fontWeight: '600' as const, textTransform: 'uppercase' as const, letterSpacing: 0.5 },
    tableHeader: { fontSize: 11, fontWeight: '600' as const, textTransform: 'uppercase' as const },
    tableCell: { fontSize: 15, fontWeight: '400' as const },
    statValue: { fontSize: 32, fontWeight: '700' as const },
    statLabel: { fontSize: 11, fontWeight: '600' as const, textTransform: 'uppercase' as const, letterSpacing: 1 },
  },
};
