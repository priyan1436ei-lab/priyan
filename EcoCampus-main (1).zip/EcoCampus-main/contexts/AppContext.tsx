import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  zones as initialZones,
  alerts as initialAlerts,
  suggestions as initialSuggestions,
  campusTotals as initialTotals,
  Zone,
  Alert,
  Suggestion,
} from '@/services/mockData';

interface AppState {
  zones: Zone[];
  alerts: Alert[];
  suggestions: Suggestion[];
  campusTotals: typeof initialTotals;
  unreadAlertCount: number;
  dismissedSuggestions: string[];
  markAlertRead: (id: string) => void;
  markAllAlertsRead: () => void;
  dismissSuggestion: (id: string) => void;
  refreshData: () => void;
}

const AppContext = createContext<AppState | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [zones] = useState<Zone[]>(initialZones);
  const [alerts, setAlerts] = useState<Alert[]>(initialAlerts);
  const [suggestions] = useState<Suggestion[]>(initialSuggestions);
  const [campusTotals] = useState(initialTotals);
  const [dismissedSuggestions, setDismissedSuggestions] = useState<string[]>([]);

  useEffect(() => {
    AsyncStorage.getItem('dismissedSuggestions').then((d) => {
      if (d) setDismissedSuggestions(JSON.parse(d));
    });
    AsyncStorage.getItem('alerts').then((d) => {
      if (d) setAlerts(JSON.parse(d));
    });
  }, []);

  useEffect(() => {
    AsyncStorage.setItem('dismissedSuggestions', JSON.stringify(dismissedSuggestions));
  }, [dismissedSuggestions]);

  useEffect(() => {
    AsyncStorage.setItem('alerts', JSON.stringify(alerts));
  }, [alerts]);

  const unreadAlertCount = alerts.filter((a) => !a.read).length;

  const markAlertRead = useCallback((id: string) => {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, read: true } : a)));
  }, []);

  const markAllAlertsRead = useCallback(() => {
    setAlerts((prev) => prev.map((a) => ({ ...a, read: true })));
  }, []);

  const dismissSuggestion = useCallback((id: string) => {
    setDismissedSuggestions((prev) => [...prev, id]);
  }, []);

  const refreshData = useCallback(() => {
    // Simulated refresh — data stays the same for prototype
  }, []);

  return (
    <AppContext.Provider
      value={{
        zones,
        alerts,
        suggestions,
        campusTotals,
        unreadAlertCount,
        dismissedSuggestions,
        markAlertRead,
        markAllAlertsRead,
        dismissSuggestion,
        refreshData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
