export interface Zone {
  id: string;
  name: string;
  type: 'hostel' | 'lab' | 'canteen' | 'library' | 'admin';
  icon: string;
  color: string;
  electricity: {
    current: number;
    limit: number;
    unit: string;
    trend: number;
  };
  water: {
    current: number;
    limit: number;
    unit: string;
    trend: number;
  };
  status: 'normal' | 'warning' | 'critical';
  devices: number;
  lastUpdated: string;
}

export interface Alert {
  id: string;
  type: 'high_power' | 'water_leak' | 'abnormal_spike' | 'prediction_warning' | 'saving_tip';
  severity: 'info' | 'warning' | 'critical';
  title: string;
  message: string;
  zone: string;
  timestamp: string;
  read: boolean;
  icon: string;
}

export interface DailyUsage {
  day: string;
  electricity: number;
  water: number;
}

export interface HourlyUsage {
  hour: string;
  electricity: number;
  water: number;
}

export interface Suggestion {
  id: string;
  title: string;
  description: string;
  savingsEstimate: string;
  priority: 'high' | 'medium' | 'low';
  category: 'electricity' | 'water' | 'both';
  icon: string;
}

export interface Prediction {
  date: string;
  predictedElectricity: number;
  predictedWater: number;
  confidence: number;
}

// ---------- ZONES ----------
export const zones: Zone[] = [
  {
    id: 'hostel-a',
    name: 'Hostel A',
    type: 'hostel',
    icon: 'apartment',
    color: '#3B82F6',
    electricity: { current: 487, limit: 700, unit: 'kWh', trend: -3.2 },
    water: { current: 2150, limit: 3000, unit: 'L', trend: 1.8 },
    status: 'normal',
    devices: 24,
    lastUpdated: '2 min ago',
  },
  {
    id: 'hostel-b',
    name: 'Hostel B',
    type: 'hostel',
    icon: 'apartment',
    color: '#8B5CF6',
    electricity: { current: 623, limit: 700, unit: 'kWh', trend: 8.5 },
    water: { current: 2870, limit: 3000, unit: 'L', trend: 12.3 },
    status: 'warning',
    devices: 28,
    lastUpdated: '1 min ago',
  },
  {
    id: 'lab-block',
    name: 'Lab Block',
    type: 'lab',
    icon: 'science',
    color: '#10B981',
    electricity: { current: 890, limit: 1000, unit: 'kWh', trend: 5.1 },
    water: { current: 1200, limit: 2000, unit: 'L', trend: -1.4 },
    status: 'warning',
    devices: 42,
    lastUpdated: '30 sec ago',
  },
  {
    id: 'canteen',
    name: 'Canteen',
    type: 'canteen',
    icon: 'restaurant',
    color: '#F59E0B',
    electricity: { current: 345, limit: 500, unit: 'kWh', trend: -5.7 },
    water: { current: 3800, limit: 4000, unit: 'L', trend: 15.2 },
    status: 'critical',
    devices: 18,
    lastUpdated: '45 sec ago',
  },
  {
    id: 'library',
    name: 'Library',
    type: 'library',
    icon: 'local-library',
    color: '#EC4899',
    electricity: { current: 210, limit: 400, unit: 'kWh', trend: -2.1 },
    water: { current: 420, limit: 800, unit: 'L', trend: 0.3 },
    status: 'normal',
    devices: 14,
    lastUpdated: '3 min ago',
  },
  {
    id: 'admin-block',
    name: 'Admin Block',
    type: 'admin',
    icon: 'business',
    color: '#6366F1',
    electricity: { current: 178, limit: 350, unit: 'kWh', trend: -1.0 },
    water: { current: 580, limit: 1000, unit: 'L', trend: -0.5 },
    status: 'normal',
    devices: 10,
    lastUpdated: '5 min ago',
  },
];

// ---------- WEEKLY USAGE ----------
export const weeklyUsage: DailyUsage[] = [
  { day: 'Mon', electricity: 2450, water: 9800 },
  { day: 'Tue', electricity: 2680, water: 10200 },
  { day: 'Wed', electricity: 2320, water: 9400 },
  { day: 'Thu', electricity: 2890, water: 11300 },
  { day: 'Fri', electricity: 2710, water: 10800 },
  { day: 'Sat', electricity: 1950, water: 7600 },
  { day: 'Sun', electricity: 1720, water: 6900 },
];

// ---------- HOURLY USAGE (Today) ----------
export const hourlyUsage: HourlyUsage[] = [
  { hour: '00', electricity: 45, water: 120 },
  { hour: '01', electricity: 38, water: 95 },
  { hour: '02', electricity: 32, water: 80 },
  { hour: '03', electricity: 28, water: 70 },
  { hour: '04', electricity: 25, water: 65 },
  { hour: '05', electricity: 35, water: 110 },
  { hour: '06', electricity: 78, water: 280 },
  { hour: '07', electricity: 145, water: 520 },
  { hour: '08', electricity: 210, water: 680 },
  { hour: '09', electricity: 245, water: 720 },
  { hour: '10', electricity: 260, water: 690 },
  { hour: '11', electricity: 270, water: 650 },
  { hour: '12', electricity: 290, water: 780 },
  { hour: '13', electricity: 275, water: 710 },
  { hour: '14', electricity: 255, water: 640 },
  { hour: '15', electricity: 240, water: 600 },
  { hour: '16', electricity: 230, water: 580 },
  { hour: '17', electricity: 215, water: 620 },
  { hour: '18', electricity: 250, water: 750 },
  { hour: '19', electricity: 280, water: 820 },
  { hour: '20', electricity: 265, water: 760 },
  { hour: '21', electricity: 220, water: 580 },
  { hour: '22', electricity: 160, water: 380 },
  { hour: '23', electricity: 85, water: 210 },
];

// ---------- ALERTS ----------
export const alerts: Alert[] = [
  {
    id: 'a1',
    type: 'water_leak',
    severity: 'critical',
    title: 'Possible Water Leakage',
    message: 'Canteen water usage spiked 42% above normal at 2:30 AM when no activity expected. Immediate inspection recommended.',
    zone: 'Canteen',
    timestamp: '15 min ago',
    read: false,
    icon: 'water-damage',
  },
  {
    id: 'a2',
    type: 'high_power',
    severity: 'warning',
    title: 'High Power Usage Detected',
    message: 'Hostel B electricity consumption exceeded 89% of daily limit. 6 AC units running simultaneously in Block C.',
    zone: 'Hostel B',
    timestamp: '32 min ago',
    read: false,
    icon: 'bolt',
  },
  {
    id: 'a3',
    type: 'abnormal_spike',
    severity: 'warning',
    title: 'Abnormal Energy Spike',
    message: 'Lab Block registered 23% higher electricity usage than predicted. Equipment may be left running overnight.',
    zone: 'Lab Block',
    timestamp: '1 hr ago',
    read: false,
    icon: 'trending-up',
  },
  {
    id: 'a4',
    type: 'prediction_warning',
    severity: 'info',
    title: 'Tomorrow: Peak Usage Expected',
    message: 'AI predicts 15% higher electricity usage tomorrow due to scheduled lab sessions and exam week patterns.',
    zone: 'Campus-wide',
    timestamp: '2 hrs ago',
    read: true,
    icon: 'psychology',
  },
  {
    id: 'a5',
    type: 'saving_tip',
    severity: 'info',
    title: 'Energy Saving Opportunity',
    message: 'Library AC runs at full capacity during low-occupancy hours (2-4 PM). Adjusting thermostat can save ₹1,200/month.',
    zone: 'Library',
    timestamp: '3 hrs ago',
    read: true,
    icon: 'eco',
  },
  {
    id: 'a6',
    type: 'high_power',
    severity: 'critical',
    title: 'Circuit Overload Risk',
    message: 'Hostel A Block D drawing 95% of circuit capacity. Multiple high-wattage appliances detected.',
    zone: 'Hostel A',
    timestamp: '4 hrs ago',
    read: true,
    icon: 'warning',
  },
  {
    id: 'a7',
    type: 'water_leak',
    severity: 'warning',
    title: 'Unusual Water Flow',
    message: 'Admin Block restroom sensor detected continuous flow for 45+ minutes. Possible faulty tap or flush.',
    zone: 'Admin Block',
    timestamp: '5 hrs ago',
    read: true,
    icon: 'water-damage',
  },
  {
    id: 'a8',
    type: 'saving_tip',
    severity: 'info',
    title: 'Weekend Optimization',
    message: 'Last weekend, Hostel B consumed 30% more water than needed. Auto-scheduling water pumps can save 800L/weekend.',
    zone: 'Hostel B',
    timestamp: '6 hrs ago',
    read: true,
    icon: 'eco',
  },
  {
    id: 'a9',
    type: 'abnormal_spike',
    severity: 'warning',
    title: 'Lab Equipment Left On',
    message: 'Heat sensor and power data suggest 3 lab stations in Room 204 were not powered down after 8 PM.',
    zone: 'Lab Block',
    timestamp: '8 hrs ago',
    read: true,
    icon: 'power-settings-new',
  },
  {
    id: 'a10',
    type: 'prediction_warning',
    severity: 'info',
    title: 'Monthly Bill Forecast',
    message: 'At current rate, this month\'s EB bill will be ₹47,800 — 12% above budget. Reducing Lab Block usage can save ₹5,200.',
    zone: 'Campus-wide',
    timestamp: '12 hrs ago',
    read: true,
    icon: 'receipt-long',
  },
];

// ---------- SUGGESTIONS ----------
export const suggestions: Suggestion[] = [
  {
    id: 's1',
    title: 'Schedule AC Auto-Off',
    description: 'Set AC units in Hostel B to auto-shutdown between 11 PM - 6 AM during winter months.',
    savingsEstimate: '₹3,400/month',
    priority: 'high',
    category: 'electricity',
    icon: 'ac-unit',
  },
  {
    id: 's2',
    title: 'Fix Canteen Water Leak',
    description: 'Continuous flow detected at Canteen kitchen tap. Repair can prevent 200L/day wastage.',
    savingsEstimate: '6,000L/month',
    priority: 'high',
    category: 'water',
    icon: 'plumbing',
  },
  {
    id: 's3',
    title: 'Install Motion Sensors',
    description: 'Library corridors lit 24/7. Motion sensors can reduce lighting consumption by 40%.',
    savingsEstimate: '₹1,800/month',
    priority: 'medium',
    category: 'electricity',
    icon: 'sensors',
  },
  {
    id: 's4',
    title: 'Optimize Lab Schedules',
    description: 'Consolidate lab sessions to reduce idle equipment hours. Currently 35% idle time detected.',
    savingsEstimate: '₹2,600/month',
    priority: 'medium',
    category: 'electricity',
    icon: 'schedule',
  },
  {
    id: 's5',
    title: 'Rainwater Harvesting',
    description: 'Hostel A rooftop area can support harvesting system. Estimated collection: 5,000L during monsoon months.',
    savingsEstimate: '5,000L/month',
    priority: 'low',
    category: 'water',
    icon: 'water',
  },
  {
    id: 's6',
    title: 'Replace Old Geysers',
    description: 'Hostel B has 8 geysers older than 5 years. BEE 5-star models can reduce consumption by 30%.',
    savingsEstimate: '₹4,100/month',
    priority: 'high',
    category: 'both',
    icon: 'hot-tub',
  },
  {
    id: 's7',
    title: 'Smart Water Timers',
    description: 'Install timer-based taps in hostel washrooms. Average tap runs 45s longer than needed per use.',
    savingsEstimate: '3,200L/month',
    priority: 'medium',
    category: 'water',
    icon: 'timer',
  },
  {
    id: 's8',
    title: 'LED Retrofitting',
    description: 'Admin Block still uses 40W tube lights. LED replacement offers 60% energy savings on lighting.',
    savingsEstimate: '₹900/month',
    priority: 'low',
    category: 'electricity',
    icon: 'lightbulb',
  },
];

// ---------- AI PREDICTIONS ----------
export const predictions: Prediction[] = [
  { date: 'Tomorrow', predictedElectricity: 2780, predictedWater: 10500, confidence: 87 },
  { date: 'Day After', predictedElectricity: 2620, predictedWater: 9800, confidence: 82 },
  { date: 'In 3 Days', predictedElectricity: 2900, predictedWater: 11200, confidence: 76 },
];

// ---------- MONTHLY TREND ----------
export const monthlyTrend = [
  { month: 'Jan', electricity: 68400, water: 285000 },
  { month: 'Feb', electricity: 62100, water: 260000 },
  { month: 'Mar', electricity: 71200, water: 298000 },
  { month: 'Apr', electricity: 78900, water: 320000 },
  { month: 'May', electricity: 85400, water: 345000 },
  { month: 'Jun', electricity: 72300, water: 290000 },
];

// ---------- CAMPUS TOTALS ----------
export const campusTotals = {
  electricity: {
    today: 2733,
    limit: 3650,
    unit: 'kWh',
    monthTotal: 72300,
    monthBudget: 85000,
    costPerUnit: 8.5,
    savedThisMonth: 12700,
  },
  water: {
    today: 11020,
    limit: 14800,
    unit: 'L',
    monthTotal: 290000,
    monthBudget: 350000,
    costPerKL: 45,
    savedThisMonth: 60000,
  },
  sustainability: {
    ecoScore: 72,
    co2Saved: 1.8, // tonnes
    treesEquivalent: 24,
    ranking: 3, // out of departments
  },
};

// ---------- ZONE DETAIL HOURLY DATA ----------
export const zoneHourlyData: Record<string, HourlyUsage[]> = {
  'hostel-a': [
    { hour: '06', electricity: 35, water: 180 },
    { hour: '07', electricity: 62, water: 340 },
    { hour: '08', electricity: 78, water: 420 },
    { hour: '09', electricity: 55, water: 280 },
    { hour: '10', electricity: 42, water: 190 },
    { hour: '11', electricity: 38, water: 160 },
    { hour: '12', electricity: 48, water: 220 },
    { hour: '13', electricity: 45, water: 200 },
    { hour: '14', electricity: 40, water: 170 },
    { hour: '15', electricity: 38, water: 150 },
    { hour: '16', electricity: 42, water: 180 },
    { hour: '17', electricity: 55, water: 250 },
    { hour: '18', electricity: 72, water: 380 },
    { hour: '19', electricity: 85, water: 420 },
    { hour: '20', electricity: 78, water: 390 },
    { hour: '21', electricity: 65, water: 320 },
    { hour: '22', electricity: 48, water: 210 },
    { hour: '23', electricity: 35, water: 150 },
  ],
  'hostel-b': [
    { hour: '06', electricity: 40, water: 200 },
    { hour: '07', electricity: 72, water: 380 },
    { hour: '08', electricity: 88, water: 460 },
    { hour: '09', electricity: 62, water: 320 },
    { hour: '10', electricity: 48, water: 210 },
    { hour: '11', electricity: 44, water: 180 },
    { hour: '12', electricity: 55, water: 250 },
    { hour: '13', electricity: 52, water: 230 },
    { hour: '14', electricity: 46, water: 190 },
    { hour: '15', electricity: 44, water: 170 },
    { hour: '16', electricity: 50, water: 200 },
    { hour: '17', electricity: 65, water: 290 },
    { hour: '18', electricity: 82, water: 420 },
    { hour: '19', electricity: 95, water: 470 },
    { hour: '20', electricity: 88, water: 430 },
    { hour: '21', electricity: 72, water: 360 },
    { hour: '22', electricity: 55, water: 240 },
    { hour: '23', electricity: 40, water: 170 },
  ],
};

// Helper to get status color
export function getStatusColor(status: 'normal' | 'warning' | 'critical'): string {
  switch (status) {
    case 'normal': return '#10B981';
    case 'warning': return '#F59E0B';
    case 'critical': return '#EF4444';
  }
}

// Helper to get severity color
export function getSeverityColor(severity: 'info' | 'warning' | 'critical'): string {
  switch (severity) {
    case 'info': return '#3B82F6';
    case 'warning': return '#F59E0B';
    case 'critical': return '#EF4444';
  }
}

// Helper to format number with commas
export function formatNumber(num: number): string {
  return num.toLocaleString('en-IN');
}
